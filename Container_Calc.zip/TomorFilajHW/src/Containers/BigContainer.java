package Containers;

//inheritance extends big container class
public class BigContainer extends Container {
    public BigContainer(double height, double wide, double length) {

        super(length, wide, height);

    }

    public String typeOfContainer() {
        return "Big";
    }


    public int price() {
        return 1800;
    }
}



package Containers;

// inheritance extends container class
public class smallContainer extends Container {
    public smallContainer(double height, double wide, double length) {

        super(length, wide, height);

    }

    public String typeOfContainer() {
        return "Small";
    }

    public int price() {
        if ((this.getWeight()) > 500) {
            return 1200;
        }
        return 1000;
    }
}

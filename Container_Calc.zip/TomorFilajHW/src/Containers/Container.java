package Containers;

import items.Item;

import java.util.ArrayList;
import java.util.List;

public abstract class Container {

    private double height = 0.0;
    private double wide = 0.0;
    private double length = 0.0;
    private List<Item> items = new ArrayList<Item>();
    private double volumeLeft = 0.0;


    public Container(double height, double wide, double length) {
        this.height = height;
        this.wide = wide;
        this.length = length;
        volumeLeft = this.getVolume();
    }

    public double getWeight() {
        double weight = 0;
        for (Item item : items) {
            weight += item.getWeight();
        }
        return weight;
    }

    public double itemVolume() {
        double volume = 0;
        for (Item item : items) {
            volume += item.getVolume();
        }
        return volume;
    }

    public double getVolume() {
        double volume = this.wide * this.height * this.length;
        return Math.round(volume * 1000.0) / 1000.0;
    }

    public List<Item> getItems() {
        return this.items;
    }

    public boolean addItem(Item item) {
        if (this.volumeLeft >= item.getVolume()) {
            this.items.add(item);
            this.volumeLeft = this.volumeLeft - item.getVolume();
            return true;
        }
        return false;
    }

    public abstract String typeOfContainer();

    public abstract int price();
}


	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	


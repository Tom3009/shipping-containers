package items;
//inheritance extends item class
public class Desktop extends Item {
	public Desktop(double weight, double length, double width, double height) {
	
		super(weight, length, width, height);
	}

	public String type(){
		return "Desktop";
	}
}


package items;


public abstract class Item {

// declaring private variables 	

    private double weight = 0.0;
    private double length = 0;
    private double width = 0;
    private double height = 0;


//Initialising class

    public Item(double weight, double length, double width, double hight) {
        this.width = width;
        this.weight = weight;
        this.height = hight;
        this.length = length;
    }

    // adding getters and setters
    public double getWeight() {
        return this.weight;
    }

	public double getVolume() {
		double volume = (this.width * this.height * this.length);
		return Math.round(volume * 1000.0) / 1000.0;
	}

	abstract public String type();
}










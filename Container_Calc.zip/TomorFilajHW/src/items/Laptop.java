package items;
//inheritance extends item class
public class Laptop extends Item {
	public Laptop(double weight, double length, double width, double height) {
	
		super(weight, length, width, height);
	}
	public String type(){
		return "Laptop";
	}
}


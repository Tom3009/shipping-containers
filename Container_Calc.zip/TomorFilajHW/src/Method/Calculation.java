package Method;

import Containers.BigContainer;
import Containers.smallContainer;
import Containers.*;
import items.Item;

import java.util.*;


public class Calculation {

    private List<Item> itemList = new ArrayList<Item>();
    private List<Container> filledContainers = new ArrayList<Container>();

    // Container objects for big and small containers
    BigContainer bigContainer = null;
    smallContainer smallContainer = null;

    public void addOrder(List<Item> itemList) {
        Collections.sort(itemList, new Comparator<Item>() {
            public int compare(Item i1, Item i2) {
                return Double.compare(i1.getVolume(), i2.getVolume());
            }
        });
        this.itemList = itemList;
    }

    public void addItem(Item item) {
        this.itemList.add(item);
    }

    // Setter method for the big container
    public void setBigContainer(BigContainer bigContainer) {
        this.bigContainer = bigContainer;
    }

    // Setter method for the small container
    public void setSmallContainer(smallContainer smallContainer) {
        this.smallContainer = smallContainer;
    }

    // Method to calculate the total volume of all items in the order
    public double volume(List<Item> itemList) {
        double totalVolume = 0;
        for (Item item : itemList) {
            totalVolume += item.getVolume();
        }
        return totalVolume;
    }

    // Method to calculate the total weight of all items in the order
    public double totalWeight(List<Item> itemList) {
        double totalWeight = 0;
        for (Item item : itemList) {
            totalWeight += item.getWeight();
        }
        return totalWeight;
    }

    // Method to determine the best shipping method based on volume and weight
    public List<Container> bestShipping() {
        List<Item> listOfItemsToFitInContainers = this.itemList;
        double volumeLeftToBeFitted = this.volume(listOfItemsToFitInContainers);
        while (volumeLeftToBeFitted > 0) {
            if (volumeLeftToBeFitted > this.smallContainer.getVolume()) {
                Container bigContainer = this.createBigContainer();
                for (Item item : listOfItemsToFitInContainers) {
                    bigContainer.addItem(item);
                }
                listOfItemsToFitInContainers.removeAll(bigContainer.getItems());
                volumeLeftToBeFitted = this.volume(listOfItemsToFitInContainers);
                this.filledContainers.add(bigContainer);
                continue;
            }

            Container aSmallContainer = this.createSmallContainer();
            for (Item item : listOfItemsToFitInContainers) {
                aSmallContainer.addItem(item);
            }
            listOfItemsToFitInContainers.removeAll(aSmallContainer.getItems());
            this.filledContainers.add(aSmallContainer);
            volumeLeftToBeFitted = this.volume(listOfItemsToFitInContainers);
        }
        return this.filledContainers;
    }

    // Method to calculate the total shipping price
    public int shippingPrice() {
        int price = 0;
        for (Container container : this.filledContainers) {
            price += container.price();
        }
        return price;
    }

    private Container createBigContainer() {
        return new BigContainer(2.59, 2.43, 12.01);
    }

    ;

    private Container createSmallContainer() {
        return new smallContainer(2.59, 2.43, 6.06);
    }

//    // Method to print the details of each item
    public void printItems(List<Container> containers) {
        long totalDesktops = 0;
        long totalMice = 0;
        long totalLcds = 0;
        long totalLaptops = 0;
        double totalWeight = 0;
        double totalVolume = 0;

        for (Container container : containers) {
            totalDesktops += container.getItems().stream().filter(item -> item.type().equals("Desktop")).count();
            totalMice += container.getItems().stream().filter(item -> item.type().equals("Mouse")).count();
            totalLcds += container.getItems().stream().filter(item -> item.type().equals("LCD")).count();
            totalLaptops += container.getItems().stream().filter(item -> item.type().equals("Laptop")).count();
            totalWeight += container.getItems().stream().mapToDouble(Item::getWeight).sum();
            totalVolume += container.getItems().stream().mapToDouble(Item::getVolume).sum();
        }

        System.out.println("TOTAL ITEMS ORDERED");
        System.out.println("Desktops: " + totalDesktops);
        System.out.println("Mice: " + totalMice);
        System.out.println("Laptops: " + totalLaptops);
        System.out.println("LCD screens: " + totalLcds);
        System.out.println("Total weight: " + totalWeight+("kg"));
        System.out.println("Total volume: " + totalVolume+("m^3"));
    }

//
//    // Method to print the details of the order
     public void printOrder() {
        long smallContainerCount = filledContainers.stream().filter(container -> container.typeOfContainer().equals("Small")).count();
        long bigContainerCount = filledContainers.stream().filter(container -> container.typeOfContainer().equals("Big")).count();
        System.out.println("BEST SHIPPING OPTION");
        System.out.println("Small containers: " + smallContainerCount);
        System.out.println("Big containers: " + bigContainerCount);

        System.out.println("Shipping Price: " + this.shippingPrice()+" Euro");
    }
}




    		   
       
        
        
        


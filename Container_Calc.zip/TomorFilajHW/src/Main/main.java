package Main;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import Containers.BigContainer;
import Containers.Container;
import Containers.smallContainer;
import Method.Calculation;
import items.*;
import items.Desktop;
import items.Laptop;
import items.LCD;
import items.Mouse;

public class main {
    public static void main(String args[]) {
        Scanner scanner = new Scanner(System.in);
        List<Item> itemList = new ArrayList<Item>();

        // Read user input for the number of items ordered
        System.out.println("Enter number of Laptops:");
        int numLaptops = scanner.nextInt();
        System.out.println("Enter number of Mice:");
        int numMice = scanner.nextInt();
        System.out.println("Enter number of Desktops:");
        int numDesktops = scanner.nextInt();
        System.out.println("Enter number of LCD screens:");
        int numLCDScreens = scanner.nextInt();

        for (int i = 0; i < numLaptops; i++) {
            itemList.add(new Laptop(6.5, 0.6, 0.5, 0.5));
        }
        for (int i = 0; i < numMice; i++) {
            itemList.add(new Mouse(0.2, 0.3, 0.3, 0.2));
        }
        for (int i = 0; i < numDesktops; i++) {
            itemList.add(new Desktop(20, 1, 1.5, 0.5));
        }
        for (int i = 0; i < numLCDScreens; i++) {
            itemList.add(new LCD(2.6, 1.2, 1.4, 0.8));
        }
        // Create container objects with specified dimensions
        BigContainer aBigContainer = new BigContainer(2.59, 2.43, 12.01);
        smallContainer aSmallContainer = new smallContainer(2.59, 2.43, 6.06);


        Laptop aLaptop = new Laptop(6.5, 0.6, 0.5, 0.5);
        Mouse aMouse = new Mouse(0.2, 0.3, 0.3, 0.2);
        Desktop aDesktop = new Desktop(20, 1, 1.5, 0.5);
        LCD aLcd = new LCD(2.6, 1.2, 1.4, 0.8);

        // Create a Calculation object and add items and orders to it
        Calculation orderCalculation = new Calculation();
        orderCalculation.addOrder(itemList);
        // Set the container types in the Calculation object
        orderCalculation.setBigContainer(aBigContainer);
        orderCalculation.setSmallContainer(aSmallContainer);
        List<Container> containers = orderCalculation.bestShipping();
        orderCalculation.printItems(containers);
        orderCalculation.printOrder();

        }

        
    }


    




